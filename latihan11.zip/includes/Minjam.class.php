<?php

class Minjam extends DB
{
    function getMinjam()
    {
        $query = "SELECT * FROM peminjaman";
        return $this->execute($query);
    }

    function add($data)
    {
        $date = $data['tdate'];
        $peminjam = $data['cmbmember'];
        $buku = $data['cmbbuku'];
        $status = "Belum Dikembalikan";

        $query = "insert into peminjaman values ('', '$date', '$peminjam', '$buku', '$status')";

        // Mengeksekusi query
        return $this->execute($query);
    }

    function delete($id)
    {

        $query = "delete FROM peminjaman WHERE id = '$id'";

        // Mengeksekusi query
        return $this->execute($query);
    }

    function statusMinjam($id)
    {

        $status = "Sudah Dikembalikan";
        $query = "update peminjaman set status = '$status' where id = '$id'";

        // Mengeksekusi query
        return $this->execute($query);
    }
}


?>