<?php

class Member extends DB
{
    function getMember()
    {
        $query = "SELECT * FROM member";
        return $this->execute($query);
    }

    function add($data)
    {
        $nim = $data['tnim'];
        $nama = $data['tnama'];
        $jurusan = $data['tjurusan'];

        $query = "insert into member values ('$nim', '$nama', '$jurusan')";

        // Mengeksekusi query
        return $this->execute($query);
    }

    function delete($nim)
    {

        $query = "delete FROM member WHERE nim = '$nim'";

        // Mengeksekusi query
        return $this->execute($query);
    }

    function update($data){
        $name = $data['tnama'];
        $nim = $data['tnim'];
        $jurusan = $data['tjurusan'];
        $query = "UPDATE member SET nama='$name', jurusan='$jurusan' WHERE nim = '$nim'";
        // Mengeksekusi query
        return $this->execute($query);
    }
}


?>