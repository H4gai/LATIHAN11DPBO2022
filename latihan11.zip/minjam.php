<?php

include("conf.php");
include("includes/Template.class.php");
include("includes/DB.class.php");
include("includes/Buku.class.php");
include("includes/Member.class.php");
include("includes/Minjam.class.php");

$Minjam = new Minjam($db_host, $db_user, $db_pass, $db_name);
$buku = new Buku($db_host, $db_user, $db_pass, $db_name);
$member = new Member($db_host, $db_user, $db_pass, $db_name);

$Minjam->open();
$buku->open();
$member->open();

$Minjam->getMinjam();
$buku->getBuku();
$member->getMember();


$status = false;
$alert = null;

if (isset($_POST['add'])) {
    //memanggil add
    $Minjam->add($_POST);
    header("location:minjam.php");
}

if (!empty($_GET['id_hapus'])) {
    //memanggil add
    $id = $_GET['id_hapus'];

    $Minjam->delete($id);
    header("location:minjam.php");
}

if (!empty($_GET['id_edit'])) {
    //memanggil add
    $id = $_GET['id_edit'];

    $Minjam->statusMinjam($id);
    header("location:minjam.php");
}

$data = null;
$dataBuku = null;
$dataMember = null;
$no = 1;

while (list($id, $judul) = $buku->getResult()) {
    $dataBuku .= "<option value='".$id."'>".$judul."</option>
                ";
}

while (list($nim, $nama) = $member->getResult()) {
    $dataMember .= "<option value='".$nim."'>".$nama."</option>
                ";
}

while (list($id, $date, $peminjam, $buku, $status) = $Minjam->getResult()) {
    
    if ($status == "Sudah Dikembalikan") {
        $data .= "<tr>
            <td>" . $no++ . "</td>
            <td>" . $date . "</td>
            <td>" . $peminjam . "</td>
            <td>" . $buku . "</td>
            <td>" . $status . "</td>
            <td>
            <a href='minjam.php?id_hapus=" . $id . "' class='btn btn-danger' '>Hapus</a>
            </td>
            </tr>";
    }
    else {
        $data .= "<tr>
            <td>" . $no++ . "</td>
            <td>" . $date . "</td>
            <td>" . $peminjam . "</td>
            <td>" . $buku . "</td>
            <td>" . $status . "</td>
            <td>
            <a href='minjam.php?id_edit=" . $id .  "' class='btn btn-warning' '>Edit</a>
            <a href='minjam.php?id_hapus=" . $id . "' class='btn btn-danger' '>Hapus</a>
            </td>
            </tr>";
    }
}



$tpl = new Template("templates/minjam.html");
$tpl->replace("OPTION1", $dataMember);
$tpl->replace("OPTION2", $dataBuku);
$tpl->replace("DATA_TABEL", $data);
$tpl->write();
